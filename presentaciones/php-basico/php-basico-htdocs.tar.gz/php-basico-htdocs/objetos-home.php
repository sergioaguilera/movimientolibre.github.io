<?php
/**
 * Ejemplo de sitio web usando programacion orientada a objetos
 */

/**
 * Home
 */
$titulo    = "Grupo de Usaurios de Linux de La Laguna";
$contenido = array(
	'Bienvenido'           => "Proyecto cuya finalidad es la de crear un grupo de usuarios de GNU/Linux funcional.",
	'Para unirse al grupo' => " Si estas interesado en unirte al grupo de trabajo envía un mail a: hostmaster(en)gulag.org.mx");
require_once('inc/plantilla.php');

?>
