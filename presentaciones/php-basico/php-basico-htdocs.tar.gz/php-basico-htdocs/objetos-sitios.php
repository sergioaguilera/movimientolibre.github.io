<?php
/**
 * Ejemplo de sitio web usando programacion orientada a objetos
 */

/**
 * Sitios de interés
 */
$titulo = "Sitios de interés";
require_once('clases/listado_sitios.php');
$sitios = new Listado_Sitios();
try {
	$sitios->consultar();
	$contenido = array('Sitios de interés' => $sitios->listado());
} catch (Exception $e) {
	$contenido = array('Error' => $e->getMessage());
}
require_once('inc/plantilla.php');

?>
