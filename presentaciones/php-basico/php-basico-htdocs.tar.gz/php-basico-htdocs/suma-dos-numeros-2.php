<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Suma dos numeros</title>
	</head>
	<body>
		<h2>Sumar dos n&uacute;meros</h2>
		<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
			<table>
				<tr>
					<td>N&uacute;mero</td>
					<td><input type="text" name="num_1" size="12" maxlength="12" value="<?php echo $_POST['num_1']; ?>"></td>
				</tr>
				<tr>
					<td>N&uacute;mero</td>
					<td><input type="text" name="num_2" size="12" maxlength="12" value="<?php echo $_POST['num_2']; ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><button name="submit" value="Sumar" type="submit">Sumar</button></td>
				</tr>
			</table>
		</form>
<?php
	if (!empty($_POST['num_1']) || !empty($_POST['num_2'])) {
?>
		<h2>Resultado = <?php echo $_POST['num_1'] + $_POST['num_2']; ?></h2>
<?php
	}
?>
	</body>
</html>
