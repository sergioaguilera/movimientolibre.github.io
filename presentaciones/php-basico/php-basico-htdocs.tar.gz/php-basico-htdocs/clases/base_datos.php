<?php
/**
 * base_datos.php
 *
 * @package BD
 */

/**
 * Clase BD_Motor
 *
 * @package BD
 */
class BD_Motor {

	public $bd_nombre;
	protected $servidor;
	protected $usuario;
	protected $password;
	protected $bd_recurso;

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->servidor  = 'localhost';
		$this->usuario   = 'postgres';
		$this->password  = 'postgres';
		$this->bd_nombre = 'exposicion_php_basico';
	} // constructor

	/**
	 * Conectarse a la BD
	 * @return bool Verdadero si tiene exito
	 */
	protected function conectar() {
		$bdr = pg_connect("host='$this->servidor' port=5432 dbname='$this->bd_nombre' user='$this->usuario' password='$this->password'"); 
		if (is_resource($bdr)) {
			$this->bd_recurso = $bdr;
		} else {
			throw new Exception("Error al conectarse a la BD.");
		}
		return true;
	} // conectarse

	/**
	 * Ejecutar un Comando SQL
	 * @param string Comando SQL
	 * @return resource Objeto de clase BD_Control
	 */
	public function comando($comando_sql) {
		if (!$this->bd_recurso) {
			$this->conectar();
		}
		$resultado = @pg_query($this->bd_recurso, $comando_sql);
		if (!$resultado) {
			throw new Exception(pg_last_error($this->bd_recurso)."<br><pre>$comando_sql</pre>");
		} elseif (!is_resource($resultado)) {
			return true;
		} else {
			$control = new BD_Control($this->bd_recurso);
			$control->resultado = $resultado;
			return $control;
		}
	} // ejecutar

} // clase BD_Motor

/**
 * Clase BD_Motor
 *
 * @package BD
 */
class BD_Control {

	public $resultado;
	protected $bd_recurso;

	/**
	 * Constructor
	 */
	public function __construct($in_bd_recurso) {
		if (is_resource($in_bd_recurso)) {
			$this->bd_recurso = $in_bd_recurso;
		} else {
			throw new Exception("No hay conexion valida a la BD.");
		}
	} // constructor

	/**
	 * La cantidad de registros de la consulta
	 * @return integer
	 */
	public function cantidad_registros() {
		return pg_num_rows($this->resultado);
	} // cantidad_registros

	/**
	 * Entrega un registro de la consulta
	 * @return array
	 */
	public function obtener_registro() {
		return pg_fetch_assoc($this->resultado);
	} // obtener_registro

	/**
	 * Entrega todos los registros de la consulta
	 * @return array
	 */
	public function obtener_todos_los_registros() {
		$arr = array();
		while ($registro = $this->obtener_registro()) {
			$arr[] = $registro;
		}
		return $arr;
	} // obtener_todos_los_registros

} // clase BD_Control

?>
