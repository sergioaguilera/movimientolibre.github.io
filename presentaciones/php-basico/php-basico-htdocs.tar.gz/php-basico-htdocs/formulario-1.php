<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Prueba con un formulario</title>
	</head>
	<body>
	<h2>Prueba con un formulario</h2>
	<form action="formulario-1.php" method="post">
		<table>
			<tr>
				<td>Nombre:</td>
				<td><input type="text" name="nombre" size="80" value=""></td>
			</tr>
			<tr>
				<td>Edad:</td>
				<td><input type="text" name="edad" size="10" maxlength="3" value=""> a&ntilde;os</td>
			</tr>
			<tr>
				<td>Pasatiempo:</td>
				<td>
					<select name="pasatiempo">
						<option value="Cocina">Cocina</option>
						<option value="Computacion">Computacion</option>
						<option value="Deportes">Deportes</option>
						<option value="Viajar">Viajar</option>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td><button name="submit" value="enviar" type="submit">Enviar formulario</button></td>
			</tr>
		</table>
	</form>
	</body>
</html>
