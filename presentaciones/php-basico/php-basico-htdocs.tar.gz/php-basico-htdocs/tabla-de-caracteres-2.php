<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Tabla de Caracteres</title>
	</head>
	<body>
		<h2>Tabla de caracteres</h2>
		<table border="1" cellspacing="2" cellpadding="2">
			<tr>
				<th>C&oacute;digo</th>
				<th>Caracter</th>
			</tr>
<?php
	$inicio = ord('A');
	$final  = ord('z');
	for ($i=$inicio; $i<=$final; $i++) {
?>
			<tr>
				<td><?php echo $i; ?></td>
				<td><?php echo chr($i); ?></td>
			</tr>
<?php
	}
?>
		</table>
	</body>
</html>
