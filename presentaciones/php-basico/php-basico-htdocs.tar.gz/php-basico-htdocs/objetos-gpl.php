<?php
/**
 * Ejemplo de sitio web usando programacion orientada a objetos
 */

/**
 * Licencia GPL
 */
$titulo = "Licencia GPL";
$contenido = array('Licencia GPL' => "licencia-publica-general.html");
require_once('inc/plantilla.php');

?>
